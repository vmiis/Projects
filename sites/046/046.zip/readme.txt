
How to run a web server for this web application

1. Install NodeJS if haven't (https://nodejs.org/)
2. Run start-server.bat, you will see the a web service address, for example http://localhost:57193
3. Use a web browser to see this web application
